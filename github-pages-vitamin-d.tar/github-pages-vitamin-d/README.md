# Vitamin D Evidence Brief — GitHub Pages

This folder is ready for GitHub Pages deployment.

## Files
- `index.html` — the presentation file to publish

## Deploy with GitHub Pages
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root.
3. In GitHub, open **Settings**.
4. Open **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select your main branch.
7. Select **/(root)** as the folder.
8. Save and wait for GitHub to publish the site.

Your public link will look like:
`https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`

## Optional custom domain
In GitHub Pages settings, you can add a custom domain after the site is live.
